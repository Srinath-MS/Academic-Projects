/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemRecommendation;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.TanimotoCoefficientSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

/**
 *
 * @author srinath-pc
 */
public class Recommendation {
    public static void main(String[] args) {
		try {
			DataModel dm = new FileDataModel(new File("Data/Sam.csv"));
                        System.out.println(dm. getItemIDs());
                        
			
			TanimotoCoefficientSimilarity sim = new TanimotoCoefficientSimilarity(dm);

			GenericItemBasedRecommender recommender = new GenericItemBasedRecommender(dm, sim);

			int x=1;
			for(LongPrimitiveIterator items = dm.getItemIDs(); items.hasNext();) {
                            for(LongPrimitiveIterator users =dm.getUserIDs();users.hasNext();){
                               // System.out.println("items" +items);
				
                                long userId = users.nextLong();
                                //System.out.println("userId" +userId);
                                long itemId = items.nextLong();
                                //System.out.println("ItemId" + itemId);
                                
                                //List<RecommendedItem> recommendedUser = recommender.recommend(userId, 5);
				List<RecommendedItem>recommendations = recommender.mostSimilarItems(itemId, 4);
                                
                                //for(RecommendedItem recomm : recommendedUser){
				for(RecommendedItem recommendation : recommendations) {
					System.out.println(userId + "," + recommendation.getItemID());
				}
                                //}
				x++;
				//if(x>10) System.exit(1);
			}
                       }


		} catch (IOException e) {
			System.out.println("There was an error.");
			e.printStackTrace();
		} catch (TasteException e) {
			System.out.println("There was a Taste Exception");
			e.printStackTrace();
		}


	}
}

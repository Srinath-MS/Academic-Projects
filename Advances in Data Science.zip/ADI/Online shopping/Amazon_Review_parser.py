f = open('C:/Users/Jeremy/Desktop/Grad School/Advances in Data Science & Integration/Amazon_Reviews/Amazon_Instant_Video.txt','r')

outfile = open('C:/Users/Jeremy/Desktop/Grad School/Advances in Data Science & Integration/Amazon_Reviews/Output/Amazon_Instant_Video.txt','w')
i = 0;
for line in f.readlines():
	i+=1
	if line == '\n':
		outfile.write('\n')
	else:
		new_line = line.replace('' + line[0:line.index(':') + 2] + '','')
		outfile.write(new_line.replace('\n','') + '|')
print i;
f.close()
outfile.close()
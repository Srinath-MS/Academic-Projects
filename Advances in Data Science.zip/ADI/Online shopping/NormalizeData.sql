USE [Amazon]
GO

/****** Object:  StoredProcedure [dbo].[NormalizeData]    Script Date: 1/22/2014 7:04:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE Procedure [dbo].[NormalizeData]
AS
SET NOCOUNT ON
DECLARE @RecordNum bigint
		,@Field varchar(50)
		,@Value varchar(max)


SET @RecordNum = 0

DECLARE temp CURSOR FOR
    SELECT  Field,value
	from Reviews

    OPEN temp       

FETCH NEXT FROM temp INTO @Field,@Value

WHILE @@FETCH_STATUS=0
BEGIN
    SELECT @Field,@Value

    IF @Field = '
product/productId'
    BEGIN
		Set @RecordNum = @RecordNum + 1
        INSERT INTO Reviews_New VALUES (@RecordNum,@Value,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
    END
    ELSE
    BEGIN
		 IF @Field = 'product/title'
		 BEGIN
			UPDATE Reviews_New
			SET title = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'product/price'
		 BEGIN
			UPDATE Reviews_New
			SET price = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'review/userId'
		 BEGIN
			UPDATE Reviews_New
			SET userID = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'review/profileName'
		 BEGIN
			UPDATE Reviews_New
			SET profileName = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'review/helpfulness'
		 BEGIN
			UPDATE Reviews_New
			SET helpfulness = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'review/score'
		 BEGIN
			UPDATE Reviews_New
			SET score = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'review/time'
		 BEGIN
			UPDATE Reviews_New
			SET reviewTime = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE IF @Field = 'review/summary'
		 BEGIN
			UPDATE Reviews_New
			SET summary = @Value
			WHERE ID = @RecordNum
		 END
		 ELSE
		 BEGIN
			UPDATE Reviews_New
			SET reviewText = @Value
			WHERE ID = @RecordNum
		 END
	 END
    FETCH NEXT FROM temp INTO @Field,@Value
END
CLOSE temp;
GO



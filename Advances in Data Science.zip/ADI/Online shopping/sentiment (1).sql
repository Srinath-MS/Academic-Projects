USE [Amazon]
GO

/****** Object:  StoredProcedure [dbo].[sp_sentiment_score]    Script Date: 4/6/2014 9:36:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[sp_sentiment_score]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	DECLARE @i int
	DECLARE @rowID bigint
	DECLARE @score int
	DECLARE @sentence varchar(max)
	DECLARE @t varchar(max)
	DECLARE @tmpWord varchar(max)
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON
	SET XACT_ABORT ON
    -- Insert statements for procedure here

	DECLARE word_cursor CURSOR FOR
	SELECT RowID,reviewText
	FROM Reviews
	ORDER BY RowID desc

	OPEN word_cursor
	FETCH NEXT FROM word_cursor INTO @rowID,@sentence

	WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @i = 0

			WHILE (@i < LEN(@sentence) + 1)
			BEGIN
				SELECT @t = SUBSTRING(@sentence,@i,1)

				IF(@t != '')
				BEGIN
					SET @tmpWord = @tmpWord + @t
				END
				ELSE
				BEGIN
					SET @tmpWord = LTRIM(@tmpWord)
					SET @tmpWord = RTRIM(@tmpWord)
					IF @tmpWord IN (SELECT word FROM positive_words)
					BEGIN
						SET @score = 1
					END
					ELSE IF @tmpWord IN (SELECT word FROM negative_words)
					BEGIN
						SET @score= -1
					END
					ELSE
					BEGIN
						SET @score = 0
					END
					INSERT INTO words VALUES (@rowID, @tmpWord,@score)
					SET @tmpWord = ''
				END
				SET @i = @i + 1
				SET @t = ''
			END

		FETCH NEXT FROM word_cursor INTO @rowID,@sentence
		END
		CLOSE word_cursor
		DEALLOCATE word_cursor
		
	END

GO


